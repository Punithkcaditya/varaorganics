import type { LandingPage } from "@/types";

/**
 * Typed fallback for ad landing pages (Dev Kit §07 — populated from Supabase or
 * flat JSON). Used when the DB has no matching landing_pages row / in mock mode.
 */
export const landingPages: LandingPage[] = [
  {
    slug: "ghee-launch",
    headline: "The ghee your grandmother knew. Proved, not claimed.",
    subheadline:
      "A2 Gir Cow Bilona Ghee — hand-churned, NABL lab-tested, batch-traced. Free Bangalore delivery.",
    heroImage: "/placeholders/ghee.svg",
    trustBullets: [
      "70-parameter NABL lab report on every batch",
      "Hand-churned by the traditional bilona method",
      "QR batch traceability — scan and verify",
    ],
    productSlug: "a2-gir-cow-bilona-ghee-500ml",
    variantSize: "500ml",
    ctaLabel: "Shop Vara Ghee — ₹1,399",
    campaignId: "ghee-launch-2026",
    active: true,
  },
];
