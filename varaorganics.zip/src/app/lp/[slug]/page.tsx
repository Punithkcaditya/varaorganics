import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { CheckIcon } from "@/components/ui/Icons";
import { LandingCTA } from "@/components/lp/LandingCTA";
import { Logo } from "@/components/layout/Logo";
import { getLandingPage } from "@/features/articles/landing";
import { findByRouteSlug } from "@/features/products/queries";

// SSR, personalised per campaign (Dev Kit §07). noindex/nofollow — paid traffic
// only. Lives outside the (store) group so there is NO site navigation.
export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const lp = await getLandingPage(slug);
  return {
    title: lp?.headline ?? "Vara Organics",
    description: lp?.subheadline,
    robots: { index: false, follow: false },
  };
}

export default async function LandingPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const lp = await getLandingPage(slug);
  if (!lp) notFound();

  const resolved = await findByRouteSlug(lp.productSlug);
  if (!resolved) notFound();
  const { product } = resolved;
  const variant =
    product.variants.find((v) => v.active && v.size === lp.variantSize) ??
    product.variants.find((v) => v.active)!;

  return (
    <main id="main" className="min-h-screen bg-gradient-to-b from-navy-mid to-navy-deep">
      <div className="px-6 py-6 md:px-[8%]">
        <Logo inverse />
      </div>

      <section className="mx-auto grid max-w-[1100px] items-center gap-10 px-6 py-10 md:grid-cols-2 md:px-[8%] md:py-16">
        <div>
          <h1 className="mb-4 font-serif text-[clamp(2.25rem,4.5vw,3.5rem)] font-semibold leading-[1.08] text-ivory">
            {lp.headline}
          </h1>
          <p className="mb-8 max-w-lg text-lg font-light leading-relaxed text-ivory/70">
            {lp.subheadline}
          </p>
          <ul className="mb-9 space-y-3">
            {lp.trustBullets.map((bullet) => (
              <li key={bullet} className="flex items-center gap-3 text-ivory/85">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gold-lt/20 text-gold-lt">
                  <CheckIcon width={13} height={13} />
                </span>
                {bullet}
              </li>
            ))}
          </ul>
          <LandingCTA
            label={lp.ctaLabel}
            sku={variant.sku}
            item={{
              variantId: variant.id,
              productId: product.id,
              slug: product.slug,
              routePrefix: product.routePrefix,
              productName: product.productName,
              size: variant.size,
              price: variant.price,
              unitLabel: variant.unitLabel,
              image: product.images[0]?.url ?? null,
            }}
          />
          <p className="mt-4 text-sm font-light text-ivory/45">
            Free Bengaluru delivery · Ships in 48 hours · 7-day returns
          </p>
        </div>

        <div className="relative aspect-square overflow-hidden rounded-lg border border-gold-lt/20">
          <Image
            src={lp.heroImage ?? product.images[0]?.url ?? "/placeholders/ghee.svg"}
            alt={product.productName}
            fill
            priority
            sizes="(max-width: 768px) 100vw, 50vw"
            className="object-cover"
          />
        </div>
      </section>
    </main>
  );
}
