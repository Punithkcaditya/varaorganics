"use client";

import { useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/features/cart/store";
import { trackViewContent } from "@/lib/analytics/events";
import type { CartItem } from "@/types";

/**
 * Landing-page CTA. Fires Meta Pixel ViewContent on load (gated by consent —
 * §14), adds the campaign product to the cart on click, and goes straight to
 * checkout while preserving UTM parameters. Purchase fires later, only after
 * server-verified payment (never here).
 */
export function LandingCTA({
  item,
  label,
  sku,
}: {
  item: Omit<CartItem, "quantity">;
  label: string;
  sku: string;
}) {
  const router = useRouter();
  const addItem = useCart((s) => s.addItem);
  const viewed = useRef(false);

  useEffect(() => {
    if (viewed.current) return;
    viewed.current = true;
    trackViewContent({ productName: item.productName, price: item.price, sku });
  }, [item.productName, item.price, sku]);

  function buy() {
    addItem({ ...item, quantity: 1 });
    const utm =
      typeof window !== "undefined"
        ? window.location.search.replace(/^\?/, "")
        : "";
    router.push(utm ? `/checkout?${utm}` : "/checkout");
  }

  return (
    <button
      type="button"
      onClick={buy}
      className="rounded-[2px] bg-gold px-10 py-4 text-sm font-bold uppercase tracking-[0.16em] text-navy-deep transition-colors hover:bg-gold-lt"
    >
      {label}
    </button>
  );
}
