"use client";

import Script from "next/script";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { publicEnv } from "@/lib/validation/env";
import { trackPageView } from "@/lib/analytics/events";
import { Button } from "@/components/ui/Button";

const CONSENT_KEY = "vara-consent";
const gaId = publicEnv.NEXT_PUBLIC_GA_MEASUREMENT_ID;
const pixelId = publicEnv.NEXT_PUBLIC_META_PIXEL_ID;
const hasAnalytics = Boolean(gaId || pixelId);

/**
 * Consent-gated analytics (§18). No tracking scripts load until the user
 * accepts. A lightweight structure so analytics can be delayed where legally
 * required (UAE Phase 2 / EU traffic). Purchase is fired elsewhere, only after
 * server verification.
 */
export function AnalyticsConsent() {
  const pathname = usePathname();
  const [consent, setConsent] = useState<boolean | null>(null);

  useEffect(() => {
    // One-time read of persisted consent (external state) on mount.
    const stored = localStorage.getItem(CONSENT_KEY);
    const value = stored === "granted";
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setConsent(stored ? value : false);
    (window as unknown as { __varaConsent?: boolean }).__varaConsent = value;
  }, []);

  // Fire page_view on client navigation once consent is granted.
  useEffect(() => {
    if (consent) trackPageView(window.location.href);
  }, [pathname, consent]);

  function accept() {
    localStorage.setItem(CONSENT_KEY, "granted");
    (window as unknown as { __varaConsent?: boolean }).__varaConsent = true;
    setConsent(true);
  }

  function decline() {
    localStorage.setItem(CONSENT_KEY, "denied");
    (window as unknown as { __varaConsent?: boolean }).__varaConsent = false;
    setConsent(false);
  }

  const loadScripts = hasAnalytics && consent === true;

  return (
    <>
      {loadScripts && gaId && (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`} strategy="afterInteractive" />
          <Script id="ga-init" strategy="afterInteractive">
            {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${gaId}',{send_page_view:false});`}
          </Script>
        </>
      )}
      {loadScripts && pixelId && (
        <Script id="meta-pixel" strategy="afterInteractive">
          {`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${pixelId}');fbq('track','PageView');`}
        </Script>
      )}

      {hasAnalytics && consent === false && (
        <div
          role="region"
          aria-label="Cookie consent"
          className="fixed inset-x-0 bottom-0 z-[210] border-t border-navy/10 bg-ivory px-6 py-4 shadow-[0_-4px_24px_rgba(0,0,0,0.08)] md:flex md:items-center md:justify-between md:gap-6"
        >
          <p className="mb-3 text-sm font-light text-navy/70 md:mb-0">
            We use analytics cookies to understand how the site is used. You can accept or decline.
          </p>
          <div className="flex shrink-0 gap-3">
            <Button variant="ghost" className="px-5 py-2.5" onClick={decline}>
              Decline
            </Button>
            <Button variant="primary" className="px-5 py-2.5" onClick={accept}>
              Accept
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
