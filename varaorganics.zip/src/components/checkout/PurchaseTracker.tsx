"use client";

import { useEffect, useRef } from "react";
import { trackPurchase } from "@/lib/analytics/events";

/**
 * Fires the Purchase analytics event ONCE, using server-provided order data
 * (the order exists in the DB only after server-side verification — §18). Never
 * fires from a raw client callback.
 */
export function PurchaseTracker({ orderNumber, totalAmount }: { orderNumber: string; totalAmount: number }) {
  const fired = useRef(false);
  useEffect(() => {
    if (fired.current) return;
    fired.current = true;
    trackPurchase({ orderNumber, totalAmount });
  }, [orderNumber, totalAmount]);
  return null;
}
