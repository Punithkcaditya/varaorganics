import "server-only";
import { cache } from "react";
import { getServerSupabase } from "@/lib/supabase/server";
import { USE_MOCK_DATA } from "@/lib/validation/env";
import { safeError } from "@/lib/security/redact";
import { landingPages as mockLandingPages } from "@/data/landing-pages";
import type { LandingPage } from "@/types";
import type { LandingPagesRow } from "@/types/database";

function mapLanding(row: LandingPagesRow): LandingPage {
  return {
    slug: row.slug,
    headline: row.headline,
    subheadline: row.subheadline,
    heroImage: row.hero_image,
    trustBullets: row.trust_bullets,
    productSlug: row.product_slug,
    variantSize: row.variant_size,
    ctaLabel: row.cta_label,
    campaignId: row.campaign_id,
    active: row.active,
  };
}

export const getLandingPage = cache(async (slug: string): Promise<LandingPage | null> => {
  if (USE_MOCK_DATA) return mockLandingPages.find((l) => l.slug === slug && l.active) ?? null;
  const sb = getServerSupabase();
  if (!sb) return mockLandingPages.find((l) => l.slug === slug && l.active) ?? null;
  try {
    const { data, error } = await sb
      .from("landing_pages")
      .select("*")
      .eq("slug", slug)
      .eq("active", true)
      .maybeSingle();
    if (error) throw error;
    if (data) return mapLanding(data as LandingPagesRow);
    return mockLandingPages.find((l) => l.slug === slug && l.active) ?? null;
  } catch (err) {
    safeError("landing", "getLandingPage failed, using mock", { err: String(err) });
    return mockLandingPages.find((l) => l.slug === slug && l.active) ?? null;
  }
});
