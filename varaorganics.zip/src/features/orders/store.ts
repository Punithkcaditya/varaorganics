import "server-only";
import { getAdminSupabase } from "@/lib/supabase/admin";
import { USE_MOCK_DATA } from "@/lib/validation/env";
import { safeError } from "@/lib/security/redact";
import type { Order } from "@/types";

/**
 * Order persistence. Uses the Supabase service-role client in production; falls
 * back to an in-memory map in mock mode / when no DB is configured so the app
 * runs offline. The maps live on globalThis so the route-handler bundle and the
 * server-component bundle share ONE instance (otherwise the order-confirmed
 * page can't see an order a route handler just created). NOTE: still per-process
 * — does not survive restarts. Documented in IMPLEMENTATION_STATUS.md.
 */
interface MockOrderStore {
  memory: Map<string, Order>;
  byRazorpayOrder: Map<string, string>;
  byIdempotency: Map<string, string>;
}
const g = globalThis as unknown as { __varaOrderStore?: MockOrderStore };
const mock: MockOrderStore = (g.__varaOrderStore ??= {
  memory: new Map(),
  byRazorpayOrder: new Map(),
  byIdempotency: new Map(),
});
const { memory, byRazorpayOrder, byIdempotency } = mock;

export async function saveOrder(order: Order, idempotencyKey: string): Promise<void> {
  const sb = getAdminSupabase();
  if (USE_MOCK_DATA || !sb) {
    memory.set(order.id, order);
    if (order.razorpayOrderId) byRazorpayOrder.set(order.razorpayOrderId, order.id);
    byIdempotency.set(idempotencyKey, order.id);
    return;
  }
  try {
    const { error } = await sb.from("orders").insert({
      id: order.id,
      order_number: order.orderNumber,
      email: order.email,
      shipping_address: order.address,
      subtotal: order.subtotal,
      shipping_amount: order.shippingAmount,
      tax_amount: order.taxAmount,
      total_amount: order.totalAmount,
      currency: order.currency,
      payment_method: order.paymentMethod,
      payment_status: order.paymentStatus,
      fulfillment_status: order.fulfillmentStatus,
      razorpay_order_id: order.razorpayOrderId,
      idempotency_key: idempotencyKey,
      notes: order.notes,
    });
    if (error) throw error;
    const { error: itemsError } = await sb.from("order_items").insert(
      order.items.map((i) => ({
        order_id: order.id,
        product_name: i.productName,
        size: i.size,
        sku: i.sku,
        quantity: i.quantity,
        unit_price: i.unitPrice,
        line_total: i.lineTotal,
      })),
    );
    if (itemsError) throw itemsError;
  } catch (err) {
    safeError("orders", "saveOrder failed", { err: String(err), orderId: order.id });
    throw err;
  }
}

export async function getOrder(id: string): Promise<Order | null> {
  const sb = getAdminSupabase();
  if (USE_MOCK_DATA || !sb) return memory.get(id) ?? null;
  try {
    const { data, error } = await sb
      .from("orders")
      .select("*, order_items(*)")
      .eq("id", id)
      .maybeSingle();
    if (error) throw error;
    if (!data) return null;
    return rowToOrder(data as Record<string, unknown>);
  } catch (err) {
    safeError("orders", "getOrder failed", { err: String(err), id });
    return null;
  }
}

export async function findOrderIdByIdempotency(key: string): Promise<string | null> {
  const sb = getAdminSupabase();
  if (USE_MOCK_DATA || !sb) return byIdempotency.get(key) ?? null;
  try {
    const { data } = await sb.from("orders").select("id").eq("idempotency_key", key).maybeSingle();
    return (data as { id: string } | null)?.id ?? null;
  } catch {
    return null;
  }
}

export async function findOrderByRazorpayOrderId(rzpOrderId: string): Promise<Order | null> {
  const sb = getAdminSupabase();
  if (USE_MOCK_DATA || !sb) {
    const id = byRazorpayOrder.get(rzpOrderId);
    return id ? (memory.get(id) ?? null) : null;
  }
  try {
    const { data } = await sb
      .from("orders")
      .select("*, order_items(*)")
      .eq("razorpay_order_id", rzpOrderId)
      .maybeSingle();
    return data ? rowToOrder(data as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

export async function updateOrder(id: string, patch: Partial<Order>): Promise<void> {
  const sb = getAdminSupabase();
  if (USE_MOCK_DATA || !sb) {
    const existing = memory.get(id);
    if (existing) memory.set(id, { ...existing, ...patch });
    return;
  }
  try {
    const { error } = await sb
      .from("orders")
      .update({
        payment_status: patch.paymentStatus,
        fulfillment_status: patch.fulfillmentStatus,
        razorpay_payment_id: patch.razorpayPaymentId,
        shiprocket_shipment_id: patch.shiprocketShipmentId,
        awb_number: patch.awbNumber,
        courier_name: patch.courierName,
        tracking_url: patch.trackingUrl,
      })
      .eq("id", id);
    if (error) throw error;
  } catch (err) {
    safeError("orders", "updateOrder failed", { err: String(err), id });
    throw err;
  }
}

function rowToOrder(row: Record<string, unknown>): Order {
  const items = (row.order_items as Record<string, unknown>[] | null) ?? [];
  return {
    id: row.id as string,
    orderNumber: row.order_number as string,
    email: row.email as string,
    address: row.shipping_address as Order["address"],
    items: items.map((i) => ({
      productName: i.product_name as string,
      size: i.size as string,
      sku: i.sku as string,
      quantity: i.quantity as number,
      unitPrice: i.unit_price as number,
      lineTotal: i.line_total as number,
    })),
    subtotal: row.subtotal as number,
    shippingAmount: row.shipping_amount as number,
    taxAmount: row.tax_amount as number,
    totalAmount: row.total_amount as number,
    currency: row.currency as string,
    paymentMethod: row.payment_method as Order["paymentMethod"],
    paymentStatus: row.payment_status as Order["paymentStatus"],
    fulfillmentStatus: row.fulfillment_status as Order["fulfillmentStatus"],
    razorpayOrderId: (row.razorpay_order_id as string) ?? null,
    razorpayPaymentId: (row.razorpay_payment_id as string) ?? null,
    shiprocketShipmentId: (row.shiprocket_shipment_id as string) ?? null,
    awbNumber: (row.awb_number as string) ?? null,
    courierName: (row.courier_name as string) ?? null,
    trackingUrl: (row.tracking_url as string) ?? null,
    notes: (row.notes as string) ?? null,
    createdAt: (row.created_at as string) ?? new Date().toISOString(),
  };
}
