import "server-only";
import { cache } from "react";
import { getServerSupabase } from "@/lib/supabase/server";
import { USE_MOCK_DATA } from "@/lib/validation/env";
import { safeError } from "@/lib/security/redact";
import { allProducts, bundleProduct, catalog } from "@/data/catalog";
import type { Category, Product, ProductVariant } from "@/types";
import { mapProduct, PRODUCT_SELECT, type ProductRowWithRelations } from "./mappers";

/**
 * Product data access. Reads from Supabase (RLS: only active rows) and falls
 * back to the seeded mock catalog in mock mode or on any DB error, so pages
 * always render. React `cache()` dedupes within a request.
 */

async function fetchActiveProducts(): Promise<Product[]> {
  if (USE_MOCK_DATA) return allProducts.filter((p) => p.active);
  const sb = getServerSupabase();
  if (!sb) return allProducts.filter((p) => p.active);
  try {
    const { data, error } = await sb.from("products").select(PRODUCT_SELECT).eq("active", true);
    if (error) throw error;
    return (data as unknown as ProductRowWithRelations[]).map(mapProduct);
  } catch (err) {
    safeError("products", "fetchActiveProducts failed, using mock", { err: String(err) });
    return allProducts.filter((p) => p.active);
  }
}

export const getAllProducts = cache(fetchActiveProducts);

export const getStoreProducts = cache(async (): Promise<Product[]> => {
  const products = await getAllProducts();
  return products.filter((p) => !p.isBundle);
});

export const getFeaturedProducts = cache(async (): Promise<Product[]> => {
  const products = await getAllProducts();
  return products.filter((p) => p.featured && !p.isBundle);
});

export const getProductsByCategory = cache(async (category: Category): Promise<Product[]> => {
  const products = await getStoreProducts();
  return products.filter((p) => p.category === category);
});

export const getBundle = cache(async (slug: string): Promise<Product | null> => {
  if (USE_MOCK_DATA) return bundleProduct.slug === slug ? bundleProduct : null;
  const products = await getAllProducts();
  return products.find((p) => p.isBundle && p.slug === slug) ?? null;
});

/**
 * Resolve a fixed product URL (routePrefix + variant slug) to its product and
 * the pre-selected variant. Handles the ghee 500ml/1L two-slug case (C3).
 */
export const resolveProductRoute = cache(
  async (
    routePrefix: Category,
    slug: string,
  ): Promise<{ product: Product; variant: ProductVariant } | null> => {
    const products = await getStoreProducts();
    for (const product of products) {
      if (product.routePrefix !== routePrefix) continue;
      const variant = product.variants.find((v) => v.active && v.routeSlug === slug);
      if (variant) return { product, variant };
    }
    return null;
  },
);

/** All fixed variant slugs for a route prefix — feeds generateStaticParams. */
export const getRouteSlugsForPrefix = cache(async (routePrefix: Category): Promise<string[]> => {
  const products = await getStoreProducts();
  const slugs: string[] = [];
  for (const product of products) {
    if (product.routePrefix !== routePrefix) continue;
    for (const v of product.variants) {
      if (v.active && v.routeSlug) slugs.push(v.routeSlug);
    }
  }
  return slugs;
});

/** Related products in the same category (excludes the given product). */
export const getRelatedProducts = cache(
  async (product: Product, limit = 3): Promise<Product[]> => {
    const products = await getStoreProducts();
    return products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, limit);
  },
);

/** Resolve a product + route path from any variant routeSlug (any category). */
export const findByRouteSlug = cache(
  async (
    routeSlug: string,
  ): Promise<{ product: Product; path: string } | null> => {
    const products = await getStoreProducts();
    for (const product of products) {
      const variant = product.variants.find((v) => v.active && v.routeSlug === routeSlug);
      if (variant) return { product, path: `/${product.routePrefix}/${routeSlug}` };
    }
    return null;
  },
);

/** Look up a single variant by id — used for price revalidation at checkout. */
export async function getVariantById(
  variantId: string,
): Promise<{ product: Product; variant: ProductVariant } | null> {
  const products = await getAllProducts();
  for (const product of products) {
    const variant = product.variants.find((v) => v.id === variantId);
    if (variant) return { product, variant };
  }
  return null;
}

/** Mock catalog access (non-cached) for build-time param generation safety. */
export function mockActiveRouteSlugs(routePrefix: Category): string[] {
  return catalog
    .filter((p) => p.active && p.routePrefix === routePrefix)
    .flatMap((p) => p.variants.filter((v) => v.active && v.routeSlug).map((v) => v.routeSlug!));
}
