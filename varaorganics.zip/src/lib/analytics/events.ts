import type { CartItem, Order } from "@/types";

/**
 * Analytics event helpers (GA4 + Meta Pixel). All calls are no-ops until
 * consent is granted and the scripts have loaded (see ConsentGate + Analytics).
 * Purchase must only be fired after server-verified payment (§18) — call
 * trackPurchase only from the order-confirmed page using server order data.
 */

type Gtag = (...args: unknown[]) => void;
type Fbq = (...args: unknown[]) => void;

interface AnalyticsWindow extends Window {
  gtag?: Gtag;
  fbq?: Fbq;
  __varaConsent?: boolean;
}

function w(): AnalyticsWindow | null {
  return typeof window === "undefined" ? null : (window as AnalyticsWindow);
}

function consented(): boolean {
  const win = w();
  return !!win && win.__varaConsent === true;
}

function ga(event: string, params: Record<string, unknown>) {
  const win = w();
  if (win?.gtag && consented()) win.gtag("event", event, params);
}

function pixel(event: string, params: Record<string, unknown>) {
  const win = w();
  if (win?.fbq && consented()) win.fbq("track", event, params);
}

export function trackPageView(url: string) {
  const win = w();
  if (win?.gtag && consented()) win.gtag("event", "page_view", { page_location: url });
  if (win?.fbq && consented()) win.fbq("track", "PageView");
}

export function trackViewContent(item: { productName: string; price: number; sku: string }) {
  ga("view_item", { currency: "INR", value: item.price, items: [{ item_id: item.sku }] });
  pixel("ViewContent", { content_name: item.productName, value: item.price, currency: "INR" });
}

export function trackAddToCart(item: CartItem) {
  ga("add_to_cart", {
    currency: "INR",
    value: item.price * item.quantity,
    items: [{ item_id: item.variantId, item_name: item.productName, quantity: item.quantity }],
  });
  pixel("AddToCart", {
    content_name: item.productName,
    value: item.price * item.quantity,
    currency: "INR",
  });
}

export function trackBeginCheckout(value: number) {
  ga("begin_checkout", { currency: "INR", value });
  pixel("InitiateCheckout", { value, currency: "INR" });
}

/** Fire ONLY after server-verified payment. */
export function trackPurchase(order: Pick<Order, "orderNumber" | "totalAmount">) {
  ga("purchase", {
    transaction_id: order.orderNumber,
    currency: "INR",
    value: order.totalAmount,
  });
  pixel("Purchase", { value: order.totalAmount, currency: "INR" });
}
